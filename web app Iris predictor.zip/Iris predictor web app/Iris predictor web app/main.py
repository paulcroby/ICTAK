from flask import Flask, render_template, request
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.tree import DecisionTreeClassifier
import pandas as pd
import numpy as np
import pickle as pkl
# Load the Iris dataset
iris_data = pd.read_excel("iris.xls")

# Train a decision tree classification model
iris_classifier = DecisionTreeClassifier()
iris_classifier.fit(iris_data[['SL', 'SW', 'PL', 'PW']], iris_data['Classification'])
pkl.dump(iris_classifier,open('main.pkl','wb'))
