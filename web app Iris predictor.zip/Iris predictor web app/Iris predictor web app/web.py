from flask import Flask, render_template, request
from sklearn.tree import DecisionTreeClassifier
import pandas as pd
import numpy as np
import pickle as pkl

# Create a Flask app
app = Flask(__name__)
main = pkl.load(open('main.pkl','rb'))

# Define routes
@app.route("/")
def home():
      return render_template("home.html")

@app.route("/predict", methods=["POST"])
def predict():
    sepal_length = float(request.form["SL"])
    sepal_width = float(request.form["SW"])
    petal_length = float(request.form["PL"])
    petal_width = float(request.form["PW"])
    prediction = main.predict([[sepal_length, sepal_width, petal_length, petal_width]])
    return render_template("result.html", prediction=prediction)

if __name__ == '__main__':
    app.run(debug=True)